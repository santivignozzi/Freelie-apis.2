import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";

import "./globals.css";

const geistSans = Geist({
  subsets: ["latin"],
  variable: "--font-geist-sans",
});
const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
});

export const metadata: Metadata = {
  title: "Mito Marketing · Agencia de experiencias corporativas",
  description:
    "Mito es una agencia boutique que diseña, produce y comunica eventos corporativos, activaciones y experiencias de marca para conectar a las marcas con las personas.",
  metadataBase: new URL("https://mitomarketing.com"),
  openGraph: {
    title: "Mito Marketing · Agencia de experiencias corporativas",
    description:
      "Diseño, producción y comunicación de eventos corporativos y experiencias de marca.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body className="min-h-screen bg-background font-sans text-foreground">
        {children}
      </body>
    </html>
  );
}
